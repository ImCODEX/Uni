class Service:
    def __init__(self, Pizzerie, Kunde):
        self.__Pizzerie = Pizzerie
        self.__Kunde = Kunde

    def bestellen(self, k, p):
        vpa = self.__Pizzerie.index(p)
        vp = self.__Pizzerie[vpa]
        vka = self.__Kunde.index(k)
        vk = self.__Kunde[vka]
        vk.order_list.append(str(vp.name))
        vp.order_list.append(str(vk.vorname))

    def ratingGeben(self, nota, p):
        vp = self.__Pizzerie.find(p)
        vp.rating.append(int(nota))

    def lieblingsPizzerien(self, k):
        vk = self.__Kunde.find(k)
        max1 = 0
        max2 = 0
        max3 = 0
        p1 = None
        p2 = None
        p3 = None
        for pizzerie in self.__Pizzerie:
            nr = vk.order_list.count(pizzerie.name)
            if nr > max1:
                max3 = max2
                p3 = p2
                max2 = max1
                p2 = p1
                max1 = nr
                p1 = pizzerie
            elif nr > max2:
                max3 = max2
                p3 = p2
                max2 = nr
                p2 = pizzerie
            elif nr > max3:
                max3 = nr
                p3 = pizzerie
        print(p1,max1,p2,max2,p3,max3)


class Pizzierie:
    def __init__(self, name, rating):
        self.__name = name
        self.__rating = rating
        self.order_list = []

    @property
    def name(self):
        return self.__name

    @property
    def rating(self):
        return self.__rating


    @name.setter
    def name(self, other):
        self.__name = other

    @name.setter
    def rating(self, other):
        self.__rating = other

    def get_rating(self):
        return sum(self.__rating)/len(self.__rating)

    def __str__(self):
        return "Name: "+self.__name +" Rating: "+self.__rating+" Order List: "+self.__order_list

    def __repr__(self):
        return "Name: " + self.__name + " Rating: " + self.__rating + " Order List: " + self.__order_list

class Kunde:
    def __init__(self, name, vorname, cardnumber):
        self.__name = name
        self.__vorname = vorname
        self.__cardnumber = cardnumber
        self.order_list = []

    @property
    def name(self):
        return self.__name

    @property
    def vorname(self):
        return self.__vorname

    @property
    def cardnumber(self):
        return self.__cardnumber

    @name.setter
    def name(self, other):
        self.__name = other

    @name.setter
    def vorname(self, other):
        self.__vorname = other

    @name.setter
    def cardnumber(self, other):
        self.__cardnumber = other


    def __str__(self):
        return "Name: "+self.__name +" Vorname: "+self.__vorname+"Card Number: "+self.__cardnumber+" Order List: "+self.__order_list

    def __repr__(self):
        return "Name: "+self.__name +" Vorname: "+self.__vorname+"Card Number: "+self.__cardnumber+" Order List: "+self.__order_list

def main():
    lp = [Pizzierie("Pizeria1",[5]),Pizzierie("Pizeria2",[4]),Pizzierie("Pizeria4",[2])]
    lk = [Kunde("marcel","dorel","5555"),Kunde("mdsacel","dodael","552355"),Kunde("mrcqewel","ddal","5555")]
    Sv1 = Service(lp,lk)
    Sv1.bestellen(lk[1],lp[2])

main()